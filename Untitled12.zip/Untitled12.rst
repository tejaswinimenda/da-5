.. code:: ipython3

    import pandas as pd
    import numpy as np
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    import matplotlib.pyplot as plt
    # Load the data from CSV file
    df = pd.read_csv(r'C:\Users\Menda Tejaswini\Downloads\Book1.csv')
    
    # Display the first few rows to understand the structure of the data
    print(df.head())
    # Example of feature scaling
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df[['feature 1', 'feature2', 'feature3']])
    df_scaled = pd.DataFrame(scaled_features, columns=['feature 1_scaled', 'feature2_scaled', 'feature3_scaled'])
    
    # Concatenate the scaled features with the original DataFrame
    df = pd.concat([df, df_scaled], axis=1)
    # Example of PCA for feature selection
    pca = PCA(n_components=3)
    principal_components = pca.fit_transform(df[['feature 1_scaled', 'feature2_scaled', 'feature3_scaled']])
    df_pca = pd.DataFrame(data = principal_components, columns = ['PC1', 'PC2', 'PC3'])
    
    # Concatenate principal components with the original DataFrame
    df = pd.concat([df, df_pca], axis=1)
    
    # Plotting the explained variance ratio
    plt.figure(figsize=(8, 6))
    plt.bar(range(3), pca.explained_variance_ratio_, alpha=0.5, align='center')
    plt.xlabel('Principal Components')
    plt.ylabel('Explained Variance Ratio')
    plt.xticks(range(3), ['PC1', 'PC2', 'PC3'])
    plt.title('Explained Variance Ratio of Principal Components')
    plt.show()
    # Example of using Random Forest for feature importance
    X = df[['feature 1', 'feature2', 'feature3']]
    y = df['target']
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train a Random Forest model
    rf = RandomForestClassifier(random_state=42)
    rf.fit(X_train, y_train)
    
    # Get feature importances
    importances = rf.feature_importances_
    
    # Sort feature importances in descending order
    indices = np.argsort(importances)[::-1]
    
    # Plotting feature importances
    plt.figure(figsize=(8, 6))
    plt.bar(range(X.shape[1]), importances[indices], align='center')
    plt.xticks(range(X.shape[1]), X.columns[indices], rotation=45)
    plt.xlabel('Features')
    plt.ylabel('Feature Importance')
    plt.title('Feature Importance from Random Forest')
    plt.tight_layout()
    plt.show()
    # Example of using Random Forest for feature importance
    X = df[['feature 1', 'feature2', 'feature3']]
    y = df['target']
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train a Random Forest model
    rf = RandomForestClassifier(random_state=42)
    rf.fit(X_train, y_train)
    
    # Get feature importances
    importances = rf.feature_importances_
    
    # Sort feature importances in descending order
    indices = np.argsort(importances)[::-1]
    
    # Plotting feature importances
    plt.figure(figsize=(8, 6))
    plt.bar(range(X.shape[1]), importances[indices], align='center')
    plt.xticks(range(X.shape[1]), X.columns[indices], rotation=45)
    plt.xlabel('Features')
    plt.ylabel('Feature Importance')
    plt.title('Feature Importance from Random Forest')
    plt.tight_layout()
    plt.show()
    


.. parsed-literal::

       feature 1  feature2  feature3  target
    0        5.1       3.5       1.4       0
    1        4.9       3.0       1.4       0
    2        4.7       3.2       1.3       1
    3        4.6       3.1       1.5       1
    4        5.0       3.6       1.4       0
    


.. image:: output_0_1.png



.. image:: output_0_2.png



.. image:: output_0_3.png


